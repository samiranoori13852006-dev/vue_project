
<script setup>
import { ref } from 'vue'

const count = ref(0)

function increase() {
  count.value++
}

function decrease() {
  count.value--
}

function reset() {
  count.value = 0
}
</script>

<template>
  <div class="container">
    <h1>شمارنده من</h1>

    <div class="counter">
      {{ count }}
    </div>

    <div class="buttons">
      <button @click="increase">افزایش +</button>

      <button @click="decrease">کاهش -</button>

      <button @click="reset">شروع مجدد</button>
    </div>
  </div>
</template>

<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Tahoma, sans-serif;
  background: #f3f0ff;
  direction: rtl;
}

.container {
  text-align: center;
  margin: 100px auto;
  padding: 40px;
  max-width: 500px;
  background: white;
  border-radius: 20px;
  box-shadow: 0 5px 20px #00000015;
}

h1 {
  color: #56378b;
  margin-bottom: 30px;
}

.counter {
  font-size: 65px;
  font-weight: bold;
  color: #7652b5;
  margin-bottom: 30px;
}

.buttons {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 12px;
}

button {
  border: none;
  padding: 12px 18px;
  border-radius: 10px;
  background: #7652b5;
  color: white;
  cursor: pointer;
  font-size: 14px;
  transition: 0.3s;
}

button:hover {
  background: #56378b;
  transform: translateY(-3px);
}
</style>
